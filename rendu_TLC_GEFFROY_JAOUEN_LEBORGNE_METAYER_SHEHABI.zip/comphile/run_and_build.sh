mvn clean install assembly:single
cd ../
mv comphile/target/comphile-1.0-SNAPSHOT-jar-with-dependencies.jar lib/compilateur.jar