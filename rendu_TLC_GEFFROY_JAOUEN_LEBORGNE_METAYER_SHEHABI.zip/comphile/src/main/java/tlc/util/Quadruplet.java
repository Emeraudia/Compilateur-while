package tlc.util;

public class Quadruplet {
  public String op;
  public String res;
  public String arg1;
  public String arg2;

  public Quadruplet(String op, String res, String arg1, String arg2) {
    this.op = op;
    this.res = res;
    this.arg1 = arg1;
    this.arg2 = arg2;
  }
}