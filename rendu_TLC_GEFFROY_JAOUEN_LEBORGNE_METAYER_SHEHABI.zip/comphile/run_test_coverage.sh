mvn clean test jacoco:prepare-agent verify jacoco:report
mvn site